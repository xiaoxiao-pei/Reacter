import Icon from "./Icon";

export const Header = () => {
  return (
    <div className="icon">
      <Icon />
    </div>
  );
};
